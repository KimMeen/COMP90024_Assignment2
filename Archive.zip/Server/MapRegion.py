import json
from shapely.geometry import shape, Point

with open('aus_regions.json') as f:
    regions = json.load(f)

for r in regions['features']:
    polygon = shape(r['geometry'])
    r['sentiment_score'] = 1

with open("test.json","w") as out:
    out.write("var statistic = "+json.dumps(regions))